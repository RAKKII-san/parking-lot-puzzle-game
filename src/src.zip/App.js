import React, { Component } from 'react';
import BoardView from './components/BoardView.jsx';
class App extends Component
{
  constructor(props)
    {
      super(props);
      this.state = {
        puzzleNumber: 0,
        stepsTaken: 0,
        gameWin: false,
        numOfCars: 0,
      };
      //this.cars
      /*
      this.bumpCount =
        this.bumpCount.bind(this);
      */
    }
  /*
  bumpCount()
  {
    let next = this.state.counter + 1;
    this.setState({counter:next});
  }
  */
  render()
  {
    return ( <div>
      <BoardView cars={this.props.cars}/>
      <p>{}</p>
    </div> );
    /*
    <p> Count is {this.state.counter} </p>
    return(
      <div>
      <div onClick={this.bumpCount}>Click Me</div>
      <p> Count is {this.state.counter} </p>
      </div>
    );
    */
  }
}
export default App;
